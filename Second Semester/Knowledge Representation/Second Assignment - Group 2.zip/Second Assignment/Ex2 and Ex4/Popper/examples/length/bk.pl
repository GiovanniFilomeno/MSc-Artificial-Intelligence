tail([_|T],T).
head([H|_],H).
empty([]).
zero(0).
one(1).


%% succ(A,B):-
%%     B is A+1.
%% succ(A,B):-
    %% B is A+1.
succ(0,1).
succ(1,2).
succ(2,3).
succ(3,4).
succ(4,5).
succ(5,6).
succ(6,7).
succ(7,8).
succ(8,9).
succ(9,10).
