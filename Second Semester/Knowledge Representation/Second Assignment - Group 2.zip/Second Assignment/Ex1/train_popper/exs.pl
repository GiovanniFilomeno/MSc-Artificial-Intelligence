% Positive examples
pos(eastbound(east1)).
pos(eastbound(east2)).
pos(eastbound(east3)).
pos(eastbound(east4)).
pos(eastbound(east5)).

% Negative examples
neg(eastbound(west6)).
neg(eastbound(west7)).
neg(eastbound(west8)).
neg(eastbound(west9)).
neg(eastbound(west10)).
